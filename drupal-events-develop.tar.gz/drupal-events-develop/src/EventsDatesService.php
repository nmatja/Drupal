<?php

namespace Drupal\events;

/**
 * Our event dates service
 */
class EventsDatesService {
    /**
     *  Method for dates difference calculations comparing to today
     */
    public function getDateDifference($eventDate) {
        $currentDate = date('Y-m-d');
        $eventStartDate=date_create($eventDate);
        $currentDate=date_create($currentDate);
        $daysLeft=date_diff($eventStartDate,$currentDate);
        
        return abs($daysLeft->format("%R%a days"));
    }
    /**
     * Get right date format Y-m-d and type
     */
    public function getDateFormat($eventDate){
        $eventDate = strtotime($eventDate);
        $eventDate = date("Y-m-d", $eventDate);

        return $eventDate;
    }
    /**
     * Get event status - pending,active,finished
     */
    public function getEventStatus($date, $difference){
        $currentDate = date('Y-m-d');
        // get event status
        if($date < $currentDate){
            $status = 'This event already passed.';
        } else if ($date > $currentDate){
            $status = $difference . ' days left until event starts.';
        } else if ($date == $currentDate){
            $status = 'This event is happening today.';
        }

        return $status;
    }
    
}