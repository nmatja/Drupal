<?php

namespace Drupal\events\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\events\EventsDatesService;

/**
 * Provides a block called EventBlock
 * 
 * @Block(
 *  id = "events_event",
 *  admin_label = @Translation("Event status")
 * )
 */
class EventBlock extends BlockBase {

    /** 
     * {@inheritdoc}
    */
    public function build(){
        //get eventsDateService
            $eventService = \Drupal::service('events.events_dates');
        // get current node ID
            $uri = \Drupal::request()->getRequestUri();
            $uri = explode("/",$uri);
            $nid = $uri[2];
        // get event date
            $node = node_load($nid);
            $eventDate = $node->field_event_date->getString();
            $eventDate = $eventService->getDateFormat($eventDate);
            $difference = $eventService->getDateDifference($eventDate);
            $status = $eventService->getEventStatus($eventDate, $difference);

    return [
        '#type' => 'markup',
        '#markup' => $this->t($status),
        '#cache' => [
            'max-age' => 0,
        ]
    ];
}


}